import { InjectionToken } from '@angular/core';

export const listColumnNamesToken = new InjectionToken<Array<Record<string, string>>>('List Column Names');

export const listColumnNamesData: Array<Record<string, string>> = [
    {
        colName: 'NameSpace / Service',
        colId: 'src'
    },
    {
        colName: 'In Bytes',
        colId: 'bytes_in_cnt'
    },
    {
        colName: 'Out Bytes',
        colId: 'bytes_out_cnt'
    },
    {
        colName: 'Packets In',
        colId: 'packets_in_cnt'
    },
    {
        colName: 'Packets Out',
        colId: 'packets_out_cnt'
    },
    {
        colName: 'Request Count',
        colId: 'req_cnt'
    },
    {
        colName: 'Latency Avg(ms)',
        colId: 'rsptime_avg_ms'
    },
    {
        colName: 'Latency Min(ms)',
        colId: 'rsptime_min_ms'
    },
    {
        colName: 'Latency max(ms)',
        colId: 'rsptime_max_ms'
    },
    {
        colName: 'Error Count',
        colId: 'rsperr_cnt'
    },
    {
        colName: 'In Pods',
        colId: 'inPods'
    },
    {
        colName: 'Out Pods',
        colId: 'outPods'
    }
];
