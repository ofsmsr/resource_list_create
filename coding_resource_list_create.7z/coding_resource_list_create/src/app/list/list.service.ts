import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ListService {

  constructor(private http: HttpClient) { }

  getResources(): Observable<Array<Record<string, string | boolean | Array<any>>>> {
    return this.http.get('../../../assets/resources.json')
    .pipe(
      map((resp: Response) => this.parseResponse(resp))
    );
  }

  private parseResponse(resp: any): Array<Record<string, string | boolean | Array<any>>> {
    const namespaceOrService = new Set();
    const resourceSchema = resp.data[0].resourceSchema;
    const resourceData = resp.data[0].resourceData;
    const initialParsedResp = resourceData.reduce((acc, item) => {
      let parsedItem: any = {};
      let itemIndex = 0;

      for(let key in resourceSchema) {
        parsedItem[key] = {...resourceSchema[key], value: item[itemIndex] || 0};
        itemIndex++;
      }

      // for src and tgt
      namespaceOrService.add(parsedItem.src.value);
      namespaceOrService.add(parsedItem.tgt.value);

      return [...acc, parsedItem];
    }, []);

    return Array.from(namespaceOrService.values()).map(item => this.getSrcAndTgt(item, initialParsedResp));;
  }

  private getSrcAndTgt(item, initialParsedResp): Record<string, string | boolean | Array<any>> {
    let srcList = [], tgtList = [];
    initialParsedResp.forEach(resource => {
      const {src: {value: srcValue}, tgt: {value: tgtValue}} = resource;
      if (srcValue.toLowerCase() === item.toLowerCase() || tgtValue.toLowerCase() === item.toLowerCase()) {
        if (srcValue.toLowerCase() !== item.toLowerCase() && tgtValue.toLowerCase() === item.toLowerCase()) {
          srcList = [...srcList, resource];
        } else {
          tgtList = [...tgtList, resource];
        }
      }
    });
    return {
      name: item,
      isExpand: false,
      srcList,
      tgtList
    };
  }
}
