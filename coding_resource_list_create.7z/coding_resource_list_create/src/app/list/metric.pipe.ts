import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'metric' })
export class MetricPipe implements PipeTransform {
  transform(value, type = 'bytes') {
    switch (type) {
      case 'bytes': {
        let units = [];
        let unit = '';
        let temp = parseInt(value, 10);
        units = ['GiB', 'MiB', 'KiB', 'Bytes'];
        for (unit = units.pop(); units.length && temp >= 1024; unit = units.pop()) {
          temp /= 1024;
        }
        return `${unit !== 'Bytes' ? temp.toFixed(3) : temp} ${unit}`;
      }
      case 'count': {
        return new Intl.NumberFormat('en', { 
          //@ts-ignore
          notation: "compact"
        }).format(parseInt(value, 10)).toString();
      }
      case 'milliseconds': {
        const val = parseInt(value, 10);
        return val !== 0 ? parseInt(value, 10).toFixed(1) : val;
      }
      default: {
        return value;
      }
    }
  }
}
