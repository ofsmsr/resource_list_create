import { Component, Inject, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

import { ListService } from './list.service'

import { AppConstant } from '../app.constant';
import { listColumnNamesToken, listColumnNamesData } from  './list.value';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css'],
  providers: [{
    provide: listColumnNamesToken,
    useValue: listColumnNamesData
  }]
})
export class ListComponent implements OnInit, OnDestroy {
  subscription: Subscription;
  namespaceOrServiceList: Array<string> = [];
  resourceList: Array<Record<string, any>> = [];

  trackByIndex = (index: number): number => index;

  constructor(
    private router: Router,
    private listService: ListService,
    @Inject(listColumnNamesToken) public readonly listColumnNames: Readonly<Array<Record<string, string>>>) { }

  ngOnInit() {
    this.getList();
  }

  onCreate(): void {
    this.router.navigate([AppConstant.createPath]);
  }

  private getList(): void {
    this.subscription = this.listService.getResources().subscribe((resourceListResp) => {
      this.resourceList = resourceListResp;
    }, err => {
      throw err;
    });
  }

  ngOnDestroy(): void {
    this.subscription && this.subscription.unsubscribe();
  }

}
