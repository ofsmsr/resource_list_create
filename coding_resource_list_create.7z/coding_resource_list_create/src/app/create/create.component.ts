import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

import { AppConstant } from '../app.constant';
import { resourceDetailData, resourceDetailToken } from './create.value';
import { IResource, resourceDetail } from './resource.model';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css'],
  providers: [{
    provide: resourceDetailToken,
    useValue: resourceDetailData
  }]
})
export class CreateComponent implements OnInit {

  resourceForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    @Inject(resourceDetailToken) private readonly defaultResourceDetail: Readonly<resourceDetail>) { }

  ngOnInit() {
    this.createForm();
  }

  onSubmit(): void {
    const resource: IResource = this.resourceForm.getRawValue();
    console.log('*****Submitted Resource Details*****', resource);
    this.onCancel();
  }

  onCancel(): void {
    this.router.navigate([AppConstant.listPath]);
  }

  private createForm(): void {
    const formDetails = {};
    this.defaultResourceDetail.forEach(item => {
      formDetails[item.fieldName as string] = [item.defaultValue, item.validators]
    });
    this.resourceForm = this.fb.group(formDetails);
  }

}
