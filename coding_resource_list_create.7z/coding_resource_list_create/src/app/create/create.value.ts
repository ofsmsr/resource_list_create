import { InjectionToken } from '@angular/core';
import { Validators } from '@angular/forms';

import { resourceDetail } from './resource.model';

export const resourceDetailToken = new InjectionToken<resourceDetail>('Resource Detail');

export const resourceDetailData: resourceDetail  = [
  {
    fieldName: 'src',
    label: 'Source',
    type: 'text',
    defaultValue: '',
    validators: [Validators.required],
    validationMessage: 'Please provide a Source'
  },
  {
    fieldName: 'tgt',
    label: 'Target',
    type: 'text',
    defaultValue: '',
    validators: [Validators.required],
    validationMessage: 'Please provide a Target'
  },
  {
    fieldName: 'bytes_in_cnt',
    label: 'In Bytes',
    type: 'number',
    defaultValue: '',
    validators: [Validators.required],
    validationMessage: 'Please provide a In Bytes'
  },
  {
    fieldName: 'bytes_out_cnt',
    label: 'Out Bytes',
    type: 'number',
    defaultValue: '',
    validators: [Validators.required],
    validationMessage: 'Please provide a Out Bytes'
  },
  {
    fieldName: 'packets_in_cnt',
    label: 'Packets In',
    type: 'number',
    defaultValue: '',
    validators: [Validators.required],
    validationMessage: 'Please provide a Packets In'
  },
  {
    fieldName: 'packets_out_cnt',
    label: 'Packets Out',
    type: 'number',
    defaultValue: null,
    validators: [Validators.required],
    validationMessage: 'Please provide a Packets Out'
  },
  {
    fieldName: 'req_cnt',
    label: 'Request Count',
    type: 'number',
    defaultValue: null,
    validators: [Validators.required],
    validationMessage: 'Please provide a Request Count'
  },
  {
    fieldName: 'rsptime_avg_ms',
    label: 'Latency Avg(ms)',
    type: 'number',
    defaultValue: null,
    validators: [Validators.required],
    validationMessage: 'Please provide a Latency Avg(ms)'
  },
  {
    fieldName: 'rsptime_min_ms',
    label: 'Latency Min(ms)',
    type: 'number',
    defaultValue: null,
    validators: [Validators.required],
    validationMessage: 'Please provide a Latency Min(ms)'
  },
  {
    fieldName: 'rsptime_max_ms',
    label: 'Latency Max(ms)',
    type: 'number',
    defaultValue: null,
    validators: [Validators.required],
    validationMessage: 'Please provide a Latency Max(ms)'
  },
  {
    fieldName: 'rsperr_cnt',
    label: 'Error Count',
    type: 'number',
    defaultValue: null
  },
  {
    fieldName: 'inPods',
    label: 'In Pods',
    type: 'number',
    defaultValue: null
  },
  {
    fieldName: 'outPods',
    label: 'Out Pods',
    type: 'number',
    defaultValue: null
  }
];
