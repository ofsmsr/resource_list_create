import { Validators } from "@angular/forms";

export interface IResource {
    src: string;
    tgt: string;
    bytes_in_cnt: number;
    bytes_out_cnt: number;
    packets_in_cnt: number;
    packets_out_cnt: number;
    req_cnt: number;
    rsptime_avg_ms: number;
    rsptime_min_ms: number;
    rsptime_max_ms: number;
    rsperr_cnt: number;
    inPods: number;
    outPods: number;
}

export type resourceDetail = Array<Record<string, string | number | Array<Validators>>>;