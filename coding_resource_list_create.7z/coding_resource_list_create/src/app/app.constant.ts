export class AppConstant {
  static readonly listPath = '/list';
  static readonly createPath = '/create';
}